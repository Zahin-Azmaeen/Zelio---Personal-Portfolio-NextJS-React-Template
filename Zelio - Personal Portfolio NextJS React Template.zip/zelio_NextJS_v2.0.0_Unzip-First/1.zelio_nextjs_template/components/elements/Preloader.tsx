export default function Preloader() {
    return (
        <>


        </>
    )
}
